<?php

namespace Gumlet;

/**
 * PHP Exception used in the ImageResize class
 */
class ImageResizeException extends \Exception
{
}
